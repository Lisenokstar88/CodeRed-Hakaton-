from docxtpl import DocxTemplate
import openpyxl

test = []
wb = openpyxl.load_workbook('Заявка (Ответы).xlsx')
sheet = wb.get_active_sheet()

for row in sheet['A2':'L5000']:
    for cellobj in row:
        if  cellobj.value == " ":
            continue
        test.append(cellobj.value)
print(test)

x = 0
admin = 'Администрация сайта'
if [x + 7] == 'оплата в банке':
    while x < len(test):
        doc = DocxTemplate("черновик квитанции.docx")
        context = {'Введите дату' : test[x], 'Введите номер' : test[x + 1], 'Путевка в лагерь' : test[x + 2], 'Родитель' : test[x + 3], 'Ребёнок' : test[x + 4], 'Директор лагеря' : admin}
        doc.render(context)
        doc.save(test[x + 3]+'.docx')
        x += 7

