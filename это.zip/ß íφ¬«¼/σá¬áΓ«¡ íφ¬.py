import pandas as pd
import numpy as np



#Логин и пароль управляющего
logA =("12345")
passA = ("55555")
#---------------------------------------------#

#Логин и пароль министерства
logM = ("55555")
passM = ("12345")
#---------------------------------------------#

#Логин и пароль лагеря 1
log1 = ("lager1")
pass1 = ("lager1")


#---------------------------------------------#

#Логин и пароль лагеря 2 
log2 = ("lager2")
pass2 = ("lager2")


#---------------------------------------------#

#Логин и пароль лагеря 3
log3 = ("lager3")
pass3 = ("lager3")


#---------------------------------------------#

#Создаем таблицу для логинов и паролей пользователей
df2 = pd.DataFrame(
#        [['12345','55555'], 
#    ['54321','55555']],
        [["-----", "-----"]],
    #Название столбцов
        columns = ['Login','Password'])
#---------------------------------------------#


# Сброс ограничений на количество выводимых рядов
pd.set_option('display.max_rows', None)
 
# Сброс ограничений на число столбцов
pd.set_option('display.max_columns', None)
 
# Сброс ограничений на количество символов в записи
pd.set_option('display.max_colwidth', None)

#все числа отражались с n количеством знаками после запятой
pd.set_option('display.float_format', '{:.25f}'.format)



#---------------------------------------------#


#Создание и заполнение таблицы лагерей
df = pd.DataFrame(
        #1
    [['Тормозок','Зима, Весна, Осень',
        'Стационарный','21.11.2023',
        '18000','Да' ],
         #2
['Солнечный город','Лето',
    'Палаточный военно-патриотический',
    '29.08.2023','15000','Нет',],
         #3
['Колокольчик','Лето',
    'Палаточно туристический',
    '22.12.2023','20000','Да',]],

#Название столбцов
columns = ['Название смены','Время года',
            'Тип','Сроки заезда',
            'Стоимость','Наличие сертификата'])



#---------------------------------------------#   

vib = input ("Выберите Вход или Регистрация(v/r): ")

#Переадресация
while vib == ('v'):

    logV = input ("Введите логин: ")
    passV = input ("Введите пароль: ")


#Проверка админок
#------------------------------------------# 
    
    if logV == logA:
        if passV == passA:
            print ("Hello Admin")
            print(df.head())
            sort = input ("Выберите критерий фильтра(N/V/T/S/$/O) выход(~): ")
            if sort == ("№"):
                sort1 =(df.sort_values(by = 'Номер').head())

    
            if sort == ("N"):    
                sort1 =(df.sort_values(by = 'Название смены').head())

    
            if sort ==("V"):
                sort1 =(df.sort_values(by = 'Время года').head())
        
        
            if sort ==("T"):
                sort1 =(df.sort_values(by = 'Тип лагеря').head())

            if sort ==("S"):
                sort1 =(df.sort_values(by = 'Сроки заезда').head())


            if sort ==("$"):
                sort1 =(df.sort_values(by = 'Стоимость').head())


            if sort ==("O"):
                sort1 =(df.sort_values(by = 'Наличие сертификата').head())

            if sort ==("~"):
                break
            
#------------------------------------------#        
    
    if logV == logM:
        if passV == passM:
            print ("Hello Min")
            print(df.head())

            sort = input ("Выберите критерий фильтра(N/V/T/S/$/O): ")
            if sort == ("№"):
                sort1 =(df.sort_values(by = 'Номер').head())

    
            if sort == ("N"):    
                sort1 =(df.sort_values(by = 'Название смены').head())

    
            if sort ==("V"):
                sort1 =(df.sort_values(by = 'Время года').head())
        
        
            if sort ==("T"):
                sort1 =(df.sort_values(by = 'Тип лагеря').head())

            if sort ==("S"):
                sort1 =(df.sort_values(by = 'Сроки заезда').head())


            if sort ==("$"):
                sort1 =(df.sort_values(by = 'Стоимость').head())


            if sort ==("O"):
                sort1 =(df.sort_values(by = 'Наличие сертификата').head())             
        
#------------------------------------------#     
#Лагеря


    if logV == log1:
        if passV == pass1:
            print ("Hello Lager 1")
            
    if logV == log2:
        if passV == pass3:
            print ("Hello Lager 2")

    if logV == log3:
        if passV == pass3:
            print ("Hello Lager 3")
            
#------------------------------------------#

    sravLV = ('Login' != logV)
    sravPV = ('Password' != passV)

    if sravLV == True:
                    
        if sravPV == True:   
            print ("hi", logV)
            print(df.head())
            sort = input ("Выберите критерий фильтра(N/V/T/S/$/O): ")
            if sort == ("№"):
                sort1 =(df.sort_values(by = 'Номер').head())

    
            if sort == ("N"):    
                sort1 =(df.sort_values(by = 'Название смены').head())

    
            if sort ==("V"):
                sort1 =(df.sort_values(by = 'Время года').head())
        
        
            if sort ==("T"):
                sort1 =(df.sort_values(by = 'Тип лагеря').head())

            if sort ==("S"):
                sort1 =(df.sort_values(by = 'Сроки заезда').head())


            if sort ==("$"):
                sort1 =(df.sort_values(by = 'Стоимость').head())


            if sort ==("O"):
                sort1 =(df.sort_values(by = 'Наличие сертификата').head())


            

    else:
        print ("Неверный логин или пароль")
        break
#------------------------------------------#

            
#Создание и заполнение таблицы для пользовательских логинов и паролей

while vib == ('r'):
#----------------------------------------------------#
    print ("ok")        
    test = (1)

    while test == (1):
        logR = input ("Введите логин: ")
        passR = input ("Введите пароль: ")
        new_row ={'Login': logR,'Password': passR}
        
        df2 = df2.append(new_row, ignore_index=True)

        print(df2.head())
#----------------------------------------------------#
    
        
        test1 = input ("Новый пользователь-1, Войти-2, Назад-3: ")
        
        print (test1)
        
        if test1 == ('1') :
            continue

#Если вход
#----------------------------------------------------#
        elif test1 == ('2'):
            logL = input ("Введите логин: ")
            passL = input ("Введите пароль: ")
            
            sravL = ('Login' != logL)
            sravP = ('Password' != passL)

                
            if sravL == True:                                       
                    if sravP == True:
                    
                        print ("hi", logL)
                        print(df.head())
                        sort = input ("Выберите критерий фильтра(N/V/T/S/$/O): ")
                        if sort == ("№"):
                            sort1 =(df.sort_values(by = 'Номер').head())

    
                        if sort == ("N"):    
                            sort1 =(df.sort_values(by = 'Название смены').head())

    
                        if sort ==("V"):
                            sort1 =(df.sort_values(by = 'Время года').head())
        
        
                        if sort ==("T"):
                            sort1 =(df.sort_values(by = 'Тип лагеря').head())

                        if sort ==("S"):
                            sort1 =(df.sort_values(by = 'Сроки заезда').head())


                        if sort ==("$"):
                            sort1 =(df.sort_values(by = 'Стоимость').head())


                        if sort ==("O"):
                            sort1 =(df.sort_values(by = 'Наличие сертификата').head())
                        continue
                
            else:
                print ("Неверный логин или пароль")
                ex = input ("Назад-1: ")
                if ex == ('1'):
                    break
            
#----------------------------------------------------#
        
df2.to_csv('submission.csv') #сохранение файла




