list_L_and_V = [['lg0','vch0'],
                ['lg1','vch1'],
                ['lg1','vch1'],

                ]

login = str
voucher = str

login = input("Введите логин")
voucher = input("введиет название путевки")

rows = len(list_L_and_V)
cols = len(list_L_and_V[0])

for r in range(rows):
    if(list_L_and_V[r][0] != login):
        list_L_and_V[2][0] = login
        list_L_and_V[2][1] = voucher
        print("Ваша путевка добавлена")
        break
    else:
        for c in range(cols):
            if (list_L_and_V[r][c] == voucher):
                print("Вы уже забронировали эту путевку")





'''   
    if (list_L_and_V[r][0] == login):
        for c in range(cols):
            if (list_L_and_V[r][c] == login):
                print("Вы уже забронировали эту путевку")



#list_Login.append(login)
#list_Voucher.append(voucher)

#print(list_Login)
#print(list_Voucher)
#print(list[[1] [1]])
'''